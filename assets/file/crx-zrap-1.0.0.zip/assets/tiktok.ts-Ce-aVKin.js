(function(){console.log("[Sentinela] TikTok content script loaded!");let l=[],d="";const I=`
(function() {
  if (window.__sentinelaInjected) return;
  window.__sentinelaInjected = true;
  
  console.log('[Sentinela] Page script injected for XHR interception');
  
  const originalXHROpen = XMLHttpRequest.prototype.open;
  const originalXHRSend = XMLHttpRequest.prototype.send;
  
  XMLHttpRequest.prototype.open = function(method, url) {
    this._sentinelaUrl = url?.toString() || '';
    return originalXHROpen.apply(this, arguments);
  };
  
  XMLHttpRequest.prototype.send = function() {
    const xhr = this;
    const url = xhr._sentinelaUrl || '';
    
    xhr.addEventListener('load', function() {
      try {
        // Check if this is a post list API call
        if (url.includes('/api/post/item_list') || 
            url.includes('/api/user/post') ||
            url.includes('item_list') ||
            url.includes('/comment/list')) {
          
          const data = JSON.parse(xhr.responseText);
          console.log('[Sentinela] API URL:', url);
          console.log('[Sentinela] API Response:', data);
          
          const items = data?.itemList || data?.items || data?.data?.itemList || [];
          
          if (items.length > 0) {
            console.log('[Sentinela] Captured ' + items.length + ' posts from API');
            console.log('[Sentinela] First item sample:', items[0]);
            // Send to content script via custom event
            window.dispatchEvent(new CustomEvent('sentinela-posts', { 
              detail: { posts: items, cursor: data?.cursor || '' }
            }));
          } else {
            console.log('[Sentinela] No items found in response. Keys:', Object.keys(data || {}));
          }
        }
      } catch (e) {
        console.log('[Sentinela] Error parsing response:', e);
      }
    });
    
    return originalXHRSend.apply(this, arguments);
  };
  
  // Also intercept fetch
  const originalFetch = window.fetch;
  window.fetch = function() {
    const url = arguments[0]?.toString() || '';
    
    return originalFetch.apply(this, arguments).then(async function(response) {
      try {
        if (url.includes('/api/post/item_list') || 
            url.includes('/api/user/post') ||
            url.includes('item_list')) {
          
          const clone = response.clone();
          const data = await clone.json();
          console.log('[Sentinela] Fetch API URL:', url);
          console.log('[Sentinela] Fetch API Response:', data);
          
          const items = data?.itemList || data?.items || data?.data?.itemList || [];
          
          if (items.length > 0) {
            console.log('[Sentinela] Captured ' + items.length + ' posts from fetch');
            console.log('[Sentinela] First item sample:', items[0]);
            window.dispatchEvent(new CustomEvent('sentinela-posts', { 
              detail: { posts: items, cursor: data?.cursor || '' }
            }));
          } else {
            console.log('[Sentinela] No items in fetch response. Keys:', Object.keys(data || {}));
          }
        }
      } catch (e) {
        console.log('[Sentinela] Error parsing fetch response:', e);
      }
      return response;
    });
  };
  
  console.log('[Sentinela] XHR/Fetch interception active');
})();
`,h=document.createElement("script");h.textContent=I;(document.head||document.documentElement).appendChild(h);h.remove();window.addEventListener("sentinela-posts",(t=>{const{posts:i,cursor:r}=t.detail;console.log("[TikTok CS] Received",i.length,"posts from page context");const e=new Set(l.map(o=>o.id));for(const o of i)o.id&&!e.has(o.id)&&(l.push(o),e.add(o.id));r&&(d=r),console.log("[TikTok CS] Total captured posts:",l.length)}));function g(){const t=[],i=document.querySelectorAll('[data-e2e="user-post-item"], [class*="DivItemContainer"], [class*="DivVideoFeed"] > div');console.log("[TikTok CS] Found",i.length,"potential video containers");const r=document.querySelectorAll('a[href*="/video/"]');console.log("[TikTok CS] Found",r.length,"video links");const e=new Set;return console.log("videoLinks: ",r),r.forEach(o=>{const s=o.href,n=s.match(/\/video\/(\d+)/);if(n&&n[1]&&!e.has(n[1])){e.add(n[1]);const a=o.closest('[data-e2e="user-post-item"]')||o.closest('[class*="DivItemContainer"]')||o.parentElement?.parentElement,p=a?.querySelector("img")?.src||"",S=o.getAttribute("title")||o.getAttribute("aria-label")||"",m=a?.textContent||"",k=m.match(/(\d+(?:\.\d+)?[KMB]?)\s*(?:views?|plays?)/i),C=m.match(/(\d+(?:\.\d+)?[KMB]?)\s*(?:likes?|hearts?)/i);t.push({id:n[1],pk:n[1],link:s,caption:S,tags:"",uploaded_at:"",like_count:f(C?.[1]),comment_count:0,image_url:p,play_count:f(k?.[1]),share_count:0,collect_count:0,video_duration:0,video_url:"",music_title:"",music_author:"",author_username:y(window.location.href),author_nickname:""})}}),console.log("[TikTok CS] Extracted",t.length,"posts from DOM"),t}function f(t){if(!t)return 0;const i=parseFloat(t);return t.includes("K")||t.includes("k")?i*1e3:t.includes("M")||t.includes("m")?i*1e6:t.includes("B")||t.includes("b")?i*1e9:i}function y(t){return t.match(/@([^/?]+)/)?.[1]||""}chrome.runtime.onMessage.addListener((t,i,r)=>{switch(console.log("[TikTok CS] Received message:",t.type),t.type){case"TIKTOK_GET_PROFILE":return E().then(r),!0;case"TIKTOK_GET_POSTS":return v(t.username,t.count||35,t.cursor||"0").then(r),!0;case"TIKTOK_GET_CAPTURED_POSTS":let e=l;if(e.length===0){console.log("[TikTok CS] No captured posts, trying page data extraction...");const n=_();if(n&&n.posts.length>0)console.log("[TikTok CS] Got posts from page data:",n.posts.length),e=n.posts;else{console.log("[TikTok CS] No page data, trying DOM scraping...");const a=g();a.length>0&&(e=a)}}return console.log("[TikTok CS] Returning posts:",e.length),r({success:e.length>0,posts:e.length>0?e[0]?.desc!==void 0?e.map(n=>c(n)):e:[],cursor:d,hasMore:e.length>=30}),!0;case"TIKTOK_SCRAPE_DOM":console.log("[TikTok CS] DOM scraping requested");const o=g();return r({success:o.length>0,posts:o,cursor:"",hasMore:!1}),!0;case"TIKTOK_CLEAR_CAPTURED_POSTS":return l=[],d="",r({success:!0}),!0;case"TIKTOK_GET_COMMENTS":return O(t.awemeId,t.count||50,t.cursor||0).then(r),!0;case"TIKTOK_GET_SEC_UID":const s=T();return r({secUid:s}),!0}});async function E(){try{const t=w();return t?{success:!0,profile:t}:{success:!1,error:"Could not extract profile from page"}}catch(t){return console.error("[TikTok CS] Error getting profile:",t),{success:!1,error:String(t)}}}function w(){const t=document.getElementById("__UNIVERSAL_DATA_FOR_REHYDRATION__");if(t)try{const e=JSON.parse(t.textContent||"")?.__DEFAULT_SCOPE__?.["webapp.user-detail"]?.userInfo;if(e)return{id:e.user?.id,username:e.user?.uniqueId,fullName:e.user?.nickname,followers:e.stats?.followerCount||0,following:e.stats?.followingCount||0,bio:e.user?.signature,profilePic:e.user?.avatarMedium||e.user?.avatarThumb,post_count:e.stats?.videoCount||0}}catch(r){console.error("[TikTok CS] Error parsing __UNIVERSAL_DATA_FOR_REHYDRATION__:",r)}const i=document.getElementById("SIGI_STATE");if(i)try{const r=JSON.parse(i.textContent||""),o=window.location.pathname.match(/\/@([^/?]+)/)?.[1];if(o&&r?.UserModule?.users?.[o]){const s=r.UserModule.users[o],n=r.UserModule.stats?.[o];return{id:s.id,username:s.uniqueId,fullName:s.nickname,followers:n?.followerCount||0,following:n?.followingCount||0,bio:s.signature,profilePic:s.avatarMedium||s.avatarThumb,post_count:n?.videoCount||0}}}catch(r){console.error("[TikTok CS] Error parsing SIGI_STATE:",r)}return null}function A(){let t="";for(let i=0;i<19;i++)t+=Math.floor(Math.random()*10).toString();return t}async function M(t,i,r){try{const e="https://www.tiktok.com/api/post/item_list/",o=new URLSearchParams({secUid:t,count:r.toString(),cursor:i,aid:"1988",app_language:"en",app_name:"tiktok_web",browser_language:navigator.language||"en-US",browser_platform:navigator.platform||"Win32",device_id:A(),device_platform:"web_pc",os:"windows",screen_height:window.screen.height.toString(),screen_width:window.screen.width.toString(),priority_region:"",referer:"",root_referer:"",cookie_enabled:"true",history_len:"5",focus_state:"true",is_fullscreen:"false"});console.log("[TikTok CS] Fetching from API:",`${e}?${o.toString()}`);const s=await fetch(`${e}?${o.toString()}`,{method:"GET",credentials:"include"});if(!s.ok)throw new Error(`API error: ${s.status}`);const n=await s.json(),a=n.itemList||[];return console.log("[TikTok CS] API Fetch result:",a.length,"items","hasMore:",n.hasMore),{success:!0,posts:a.map(p=>c(p)),cursor:n.cursor||"0",hasMore:n.hasMore}}catch(e){return console.error("[TikTok CS] API fetch failed:",e),{success:!1,error:String(e)}}}async function v(t,i,r){try{if(l.length>0&&(r==="0"||r==="")){console.log("[TikTok CS] Using captured posts:",l.length);const s=l.map(n=>c(n));return{success:!0,posts:s.slice(0,i),cursor:d||"0",hasMore:s.length>=i}}const e=T();if(e){console.log("[TikTok CS] Found secUid, attempting API fetch...");const s=await M(e,r,i);if(s.success&&s.posts&&s.posts.length>0)return s}else console.log("[TikTok CS] Could not find secUid for API fetch");if(r==="0"||r===""){const s=_();if(s&&s.posts.length>0)return console.log("[TikTok CS] Extracted posts from page data fallback:",s.posts.length),{success:!0,posts:s.posts.slice(0,i),cursor:s.cursor||"0",hasMore:s.hasMore??!1}}console.log("[TikTok CS] Trying DOM scraping for posts...");const o=g();return o.length>0?(console.log("[TikTok CS] Got",o.length,"posts from DOM"),{success:!0,posts:o.slice(0,i),cursor:"0",hasMore:!1}):{success:!1,error:"Could not get posts. Please scroll down to load videos or try again."}}catch(e){return console.error("[TikTok CS] Error fetching posts:",e),{success:!1,error:String(e)}}}function T(){try{const t=document.getElementById("__UNIVERSAL_DATA_FOR_REHYDRATION__");if(t){const e=JSON.parse(t.textContent||"")?.__DEFAULT_SCOPE__?.["webapp.user-detail"]?.userInfo?.user;if(e?.secUid)return e.secUid}const i=document.getElementById("SIGI_STATE");if(i){const r=JSON.parse(i.textContent||"");if(r.UserModule?.users){const o=Object.values(r.UserModule.users).find(s=>s.secUid);if(o)return o.secUid}}}catch(t){console.error("[TikTok CS] Error extracting secUid:",t)}return null}function _(){try{console.log("[TikTok CS] Attempting to extract posts from page data...");const t=document.getElementById("__UNIVERSAL_DATA_FOR_REHYDRATION__");if(t){const e=JSON.parse(t.textContent||"");console.log("[TikTok CS] Found __UNIVERSAL_DATA_FOR_REHYDRATION__, keys:",Object.keys(e));const o=e?.__DEFAULT_SCOPE__;if(o){console.log("[TikTok CS] __DEFAULT_SCOPE__ keys:",Object.keys(o));const s=o["webapp.user-detail"];if(s){console.log("[TikTok CS] webapp.user-detail keys:",Object.keys(s)),console.log("[TikTok CS] 📦 Full userDetail structure:",JSON.stringify(s,null,2).substring(0,3e3));let n=null;if(s.userInfo?.user?.itemList?(n=s.userInfo.user.itemList,console.log("[TikTok CS] Found itemList in userInfo.user.itemList:",n.length)):s.itemList?(n=s.itemList,console.log("[TikTok CS] Found itemList directly:",n.length)):s.post?.itemList?(n=s.post.itemList,console.log("[TikTok CS] Found itemList in post.itemList:",n.length)):s.posts&&(n=s.posts,console.log("[TikTok CS] Found posts array:",n.length)),n&&Array.isArray(n)&&n.length>0){const a=n.map(u=>c(u));return{posts:a,hasMore:a.length>=30}}}if(o.ItemModule){const n=o.ItemModule;console.log("[TikTok CS] Found ItemModule in default scope");const a=Object.values(n).map(u=>c(u));if(a.length>0)return{posts:a,hasMore:a.length>=30}}}}const i=document.getElementById("SIGI_STATE");if(i){console.log("[TikTok CS] Found SIGI_STATE");const e=JSON.parse(i.textContent||"");if(console.log("[TikTok CS] SIGI_STATE keys:",Object.keys(e)),e.ItemModule&&typeof e.ItemModule=="object"){console.log("[TikTok CS] Found ItemModule in SIGI_STATE");const o=Object.values(e.ItemModule).map(s=>c(s));if(o.length>0)return{posts:o,hasMore:o.length>=30}}if(e.ItemList?.user?.list){console.log("[TikTok CS] Found ItemList.user.list in SIGI_STATE");const o=e.ItemList.user.list.map(s=>c(s));if(o.length>0)return{posts:o,hasMore:o.length>=30}}}const r=document.querySelectorAll("script");for(const e of r)if(e.textContent)try{const o=e.textContent.trim();if(!o.startsWith("{")&&!o.startsWith("["))continue;const s=JSON.parse(o);if(s?.ItemModule){console.log("[TikTok CS] Found ItemModule in script tag");const n=Object.values(s.ItemModule).map(a=>c(a));if(n.length>0)return{posts:n,hasMore:n.length>=30}}if(s?.itemList&&Array.isArray(s.itemList)){console.log("[TikTok CS] Found itemList in script tag");const n=s.itemList.map(a=>c(a));if(n.length>0)return{posts:n,hasMore:n.length>=30}}}catch{}return console.log("[TikTok CS] Could not find posts in page data. Posts may need to be fetched via API."),null}catch(t){return console.error("[TikTok CS] Error extracting posts from page:",t),null}}function c(t){const i=(t.challenges||t.textExtra||[]).filter(o=>o.hashtagName||o.title).map(o=>o.hashtagName||o.title),r=t.createTime||0,e=r?new Date(r*1e3).toISOString():"";return{id:t.id,pk:t.id,link:`https://www.tiktok.com/@${t.author?.uniqueId||t.authorMeta?.uniqueId}/video/${t.id}`,caption:t.desc||"",tags:i.join(", "),uploaded_at:e,like_count:t.stats?.diggCount||t.statsV2?.diggCount||t.diggCount||0,comment_count:t.stats?.commentCount||t.statsV2?.commentCount||t.commentCount||0,image_url:t.video?.cover||t.video?.originCover||t.cover||"",play_count:t.stats?.playCount||t.statsV2?.playCount||t.playCount||0,share_count:t.stats?.shareCount||t.statsV2?.shareCount||t.shareCount||0,collect_count:t.stats?.collectCount||t.statsV2?.collectCount||t.collectCount||0,video_duration:t.video?.duration||t.duration||0,video_url:t.video?.playAddr,music_title:t.music?.title,music_author:t.music?.authorName,author_username:t.author?.uniqueId||t.authorMeta?.uniqueId,author_nickname:t.author?.nickname||t.authorMeta?.nickname}}async function O(t,i,r){return{success:!1,error:"Comment scraping is currently disabled to prevent TikTok errors."}}chrome.runtime.sendMessage({type:"TIKTOK_CONTENT_SCRIPT_READY"});
})()

(function(){function r(){const e=document.documentElement.innerHTML.match(/"profilePage_([0-9]+)"/);return e?e[1]:null}console.log("[CRXJS] Hello world from content script!");chrome.runtime.onMessage.addListener((n,e,t)=>{if(n.type==="GET_USER_ID_FROM_PAGE"){const o=r();t({userId:o})}});
})()
